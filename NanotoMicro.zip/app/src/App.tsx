import { useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router';
import { Layout } from '@/components/Layout';
import Home from '@/pages/Home';
import ConverterPage from '@/pages/ConverterPage';
import PrefixConverterPage from '@/pages/PrefixConverterPage';
import ChartsPage from '@/pages/ChartsPage';

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

export default function App() {
  return (
    <Layout>
      <ScrollToTop />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/si-prefix-converter" element={<PrefixConverterPage />} />
        <Route path="/conversion-charts" element={<ChartsPage />} />
        <Route path="/:slug" element={<ConverterPage />} />
      </Routes>
    </Layout>
  );
}
